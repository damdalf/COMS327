//
// Created by Devin Amdahl on 2/1/22.
//

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>

#define WIDTH 80 // COLUMNS
#define HEIGHT 21 //ROWS

#define BLK   "\e[30m"
#define RED   "\e[31m"
#define GRN   "\e[32m"
#define YEL   "\e[33m"
#define BLU   "\e[34m"
#define MAG   "\e[35m"
#define CYN   "\e[36m"
#define WHT   "\e[37m"

#define B_BLK   "\e[30;1m"
#define B_RED   "\e[31;1m"
#define B_GRN   "\e[32;1m"
#define B_YEL   "\e[33;1m"
#define B_BLU   "\e[34;1m"
#define B_MAG   "\e[35;1m"
#define B_CYN   "\e[36;1m"
#define B_WHT   "\e[37;1m"

#define RESET "\e[0m"

// Function stub for printColor().
void printColor(char ch);
// Function stub for generateSeed().
int generateSeed();
// Function stub for printMap()..
void printMap(char map[HEIGHT][WIDTH]);
// Function stub for initializeMap().
void initializeMap(char map[HEIGHT][WIDTH]);
// Function stub for TallGrassRegions().
void tallGrassRegions(char map[HEIGHT][WIDTH]);
// Function stub for placeExits().
void placeExits(char map[HEIGHT][WIDTH]);
// Function stub for manuallyPlaceExits().
void manuallyPlaceExits(char map[HEIGHT][WIDTH]);
// Function stub for buildPaths().
void buildPaths(char map[HEIGHT][WIDTH]);
// Function stub for placePokeMart().
void placePokeMart(char map[HEIGHT][WIDTH]);
// Function stub for placePokeCenter().
void placePokeCenter(char map[HEIGHT][WIDTH]);
// Function stub for seededGeneration().
void seededGeneration(char map[HEIGHT][WIDTH]);
// Function stub for randomGeneration().
void randomGeneration(char map[HEIGHT][WIDTH]);

// The following variables store the coordinates of map's exits.
int northExit[2];
int eastExit[2];
int southExit[2];
int westExit[2];

// The following variables store the 'source' coordinates of the tall grass regions. todo delete
int tallGrass1[2];
int tallGrass2[2];

// The following variables store the 'source' coordinates of the clearing regions. todo delete
int clearingOne[2];
int clearingTwo[2];

// The following variables store the coordinates for the PokeMart and PokeCenter.
int pokeMartX[4];
int pokeMartY[4];
int pokeCenterX[4];
int pokeCenterY[4];

// This 2D array is how the map will actually be stored and represented in the terminal.
char mapArray[HEIGHT][WIDTH];

// This variable stores the seed that the user enters for the random generation of their world.
int seed;

int main()
{
    randomGeneration(mapArray);

    return 0;
}

// Function to print the map with color.
void printColor(char ch)
{
    switch(ch)
    {
        case '%' : // WHITE (BOLD)
            printf(B_WHT "%c", ch);
            return;
        case '.' : // GREEN
            printf(GRN "%c", ch);
            return;
        case '#' : // MAGENTA (BOLD)
            printf(B_MAG "%c", ch);
            return;
        case ':' : // YELLOW (BOLD)
            printf(B_YEL "%c", ch);
            return;
        case 'M' : // BLUE (BOLD)
            printf(B_BLU "%c", ch);
            return;
        case 'C' : // RED (BOLD)
            printf(B_RED "%c", ch);
            return;
        default:
            printf("%c", ch);
    }
}

// Function to ask the user for a seed.
int generateSeed()
{
    int seed;
    char input = 'n';

    while(1)
    {
        printf("Please enter a seed: ");
        scanf("%d", &seed);
        fflush(stdin);

        printf("You have entered %d for you seed. Is this correct? (Enter 'y' for yes, and any other character for no): ", seed);
        scanf("%c", &input);
        fflush(stdin);
        if (toupper(input) == 'Y') break;
    }

    printf("\n");

    return seed;
}

// Function to print the contents of the map.
void printMap(char map[HEIGHT][WIDTH])
{
    int i, j;

    for (i = 0; i < HEIGHT; i++)
    {
        for (j = 0; j < WIDTH; j++)
        {
            printColor(map[i][j]);
            printf(RESET);
        }

        printf("\n");
    }

    printf("\n");
}

// Function to initialize the map with rock borders and filled with clearings.
void initializeMap(char map[HEIGHT][WIDTH])
{
    int i, j;

    // Create left border.
    for (i = 0; i < HEIGHT; i++)
    {
        map[i][0] = '%';
    }

    // Create right border.
    for (i = 0; i < HEIGHT; i++)
    {
        map[i][WIDTH - 1] = '%';
    }

    // Create bottom border.
    for (j = 0; j < WIDTH; j++)
    {
        map[HEIGHT - 1][j] = '%';
    }

    // Create top border.
    for (j = 0; j < WIDTH; j++)
    {
        map[0][j] = '%';
    }

    for (i = 1; i < HEIGHT - 1; i++)
    {
        for (j = 1; j < WIDTH - 1; j++)
        {
            map[i][j] = '.';
        }
    }
}

// Function to generate the tall grass regions.
void tallGrassRegions(char map[HEIGHT][WIDTH])
{
    int i, j, k, l, x, y, tempX, tempY;

    for (i = 1; i < 3; i++)
    {
        if (i == 1)
        {
            x = ((rand() % 8) + 1);
            y = ((rand() % 40) + 1);
        }
        else if (i == 2)
        {
            x = ((rand() % 12) + 8);
            y = ((rand() % 40) + 30);
        }

        tempX = x;
        tempY = y;

        int growDown = rand() % ((HEIGHT - (5 * i)) / 2);
        int growUp = rand() % ((HEIGHT - (5 * i)) / 2);
        int growRight, growLeft;
        for (j = 0; j < growUp; j++)
        {
            if (tempX > 1)
            {
                growRight = rand() % 35;

                for (k = 0; k < growRight; k++)
                {
                    if (tempY + 1 < 79) map[tempX][tempY++] = ':';
                    else break;
                }

                growLeft = rand() % 35;

                for (l = 0; l < growLeft; l++)
                {
                    if (tempY - 1 > 0) map[tempX][tempY--] = ':';
                    else break;
                }
            }
            else break;
            tempX -= 1;
        }

        for (j = 0; j < growDown; j++)
        {
            if (tempX < 19)
            {
                growRight = rand() % 35;

                for (k = 0; k < growRight; k++)
                {
                    if (tempY + 1 < 79) map[tempX][tempY++] = ':';
                    else break;
                }

                growLeft = rand() % 35;

                for (l = 0; l < growLeft; l++)
                {
                    if (tempY - 1 > 0) map[tempX][tempY--] = ':';
                    else break;
                }
            }
            else break;
            tempX += 1;
        }
    }

    // TODO REFACTOR
}

// Function to randomly generate and place the exits for the map.
void placeExits(char map[HEIGHT][WIDTH])
{
    northExit[0] = 0;
    northExit[1] = ((rand() % 61) + 10);
    southExit[0] = 20;
    southExit[1] = ((rand() % 61) + 10);

    eastExit[1] = 79;
    eastExit[0] = ((rand() % 16) + 3);
    westExit[1] = 0;
    westExit[0] = ((rand() % 16) + 3);

    map[northExit[0]][northExit[1]] = '#';
    map[southExit[0]][southExit[1]] = '#';
    map[eastExit[0]][eastExit[1]] = '#';
    map[westExit[0]][westExit[1]] = '#';
}

// Function stub for manuallyPlaceExits().
void manuallyPlaceExits(char map[HEIGHT][WIDTH])
{

}

// Function to generate the N-S and E-W paths.
void buildPaths(char map[HEIGHT][WIDTH])
{
    int i, differenceNS, differenceEW, x, y;

    // BUILD PATH FROM N-S
    x = northExit[0];
    y = northExit[1];
    if (northExit[1] > southExit[1])
    {
        differenceNS = northExit[1] - southExit[1]; // MUST MOVE LEFT
        for (i = 0; i < 10; i++) // MOVE DOWN HALF OF THE DISTANCE
        {
            x++;
            map[x][y] = '#';
        }

        for (i = 1; i < (differenceNS / 2) + 1; i++) // FILL A BIT LEFT BEFORE MOVING LEFT
        {
            map[x - 1][y - i] = '#';
        }

        for(i = 0; i < differenceNS; i++) // MOVE LEFT UNTIL AT SAME Y AS SOUTH EXIT
        {
            y--;
            map[x][y] = '#';
        }

        for (i = 1; i < (differenceNS / 2) + 1; i++) // FILL A BIT RIGHT BEFORE MOVING DOWN
        {
            map[x + 1][y + i] = '#';
        }

        for (i = 0; i < 10; i++) // MOVE DOWN REST OF THE DISTANCE
        {
            x++;
            map[x][y] = '#';
        }

    }
    else
    {
        differenceNS = southExit[1] - northExit[1]; // MUST MOVE RIGHT
        for (i = 0; i < 10; i++) // MOVE DOWN HALF OF THE DISTANCE
        {
            x++;
            map[x][y] = '#';
        }

        for (i = 1; i < (differenceNS / 2) + 1; i++) // FILL A BIT RIGHT BEFORE MOVING RIGHT
        {
            map[x - 1][y + i] = '#';
        }

        for(i = 0; i < differenceNS; i++) // MOVE RIGHT UNTIL AT SAME Y AS SOUTH EXIT
        {
            y++;
            map[x][y] = '#';
        }

        for (i = 1; i < (differenceNS / 2) + 1; i++) // FILL A BIT LEFT BEFORE MOVING DOWN
        {
            map[x + 1][y - i] = '#';
        }

        for (i = 0; i < 10; i++) // MOVE DOWN REST OF THE DISTANCE
        {
            x++;
            map[x][y] = '#';
        }
    }

// BUILD PATH FROM E-W
    x = eastExit[0];
    y = eastExit[1];
    if (eastExit[0] > westExit[0])
    {
        differenceEW = eastExit[0] - westExit[0]; // MUST MOVE UP
        for (i = 0; i < 39; i++) // MOVE LEFT HALF OF THE DISTANCE
        {
            y--;
            map[x][y] = '#';
        }

        for (i = 1; i < (differenceEW / 2) + 1; i++) // FILL A BIT RIGHT BEFORE MOVING UP
        {
            map[x - 1][y + i] = '#';
        }

        for(i = 0; i < differenceEW; i++) // MOVE UP UNTIL AT SAME Y AS SOUTH EXIT
        {
            x--;
            map[x][y] = '#';
        }

        for (i = 1; i < (differenceNS / 2) + 1; i++) // FILL A BIT LEFT BEFORE MOVING LEFT
        {
            map[x + 1][y - i] = '#';
        }

        for (i = 0; i < 40; i++) // MOVE LEFT REST OF THE DISTANCE
        {
            y--;
            map[x][y] = '#';
        }

    }
    else
    {
        differenceEW = westExit[0] - eastExit[0]; // MUST MOVE DOWN
        for (i = 0; i < 39; i++) // MOVE LEFT HALF OF THE DISTANCE
        {
            y--;
            map[x][y] = '#';
        }

        for (i = 1; i < (differenceEW / 2) + 1; i++) // FILL A BIT RIGHT BEFORE MOVING DOWN
        {
            map[x + 1][y + i] = '#';
        }

        for(i = 0; i < differenceEW; i++) // MOVE RIGHT UNTIL AT SAME Y AS SOUTH EXIT
        {
            x++;
            map[x][y] = '#';
        }

        for (i = 1; i < (differenceEW / 2) + 1; i++) // FILL A BIT LEFT BEFORE MOVING LEFT
        {
            map[x - 1][y - i] = '#';
        }

        for (i = 0; i < 40; i++) // MOVE LEFT REST OF THE DISTANCE
        {
            y--;
            map[x][y] = '#';
        }
    }

}

// Function to place the PokeMart along the corresponding path.
void placePokeMart(char map[HEIGHT][WIDTH])
{
    /*
     * I loop through my array and look for my path (#). I take note of that (x, y) position. Then, I check if (x+1, y) is NOT terrain or
     * another path, OR if (x, y+ 1) is NOT terrain or another path. That way, you can bump the PokeCenter or PokeMart against at least 2 cells
     * of the path.
     */

    int i, j;

    for (i = 0; i < HEIGHT; i++)
    {
        for (j = 0; j < WIDTH; j++)
        {
            if (map[i][j] == '#')
            {
                if (map[i + 1][j] != '#' && map[i + 1][j] != ':' && map[i + 1][j] != '%' && map[i + 1][j] != 'M' && map[i + 1][j] != 'C' && map[i + 1][j + 1] != '#' && map[i + 1][j + 1] != ':' && map[i + 1][j + 1] != '%' && map[i + 1][j + 1] != 'M' && map[i + 1][j + 1] != 'C' && map[i + 2][j] != '#' && map[i + 2][j] != ':' && map[i + 2][j] != '%' && map[i + 2][j] != 'M' && map[i + 2][j] != 'C' && map[i + 2][j + 1] != '#' && map[i + 2][j + 1] != ':' && map[i + 2][j + 1] != '%' && map[i + 2][j + 1] != 'M' && map[i + 2][j + 1] != 'C')
                {
                    map[i + 1][j] = 'M';
                    map[i + 2][j] = 'M';
                    map[i + 1][j + 1] = 'M';
                    map[i + 2][j + 1] = 'M';

                    // STORE X COORDINATES FOR CHEATS
                    pokeCenterX[0] = i + 1;
                    pokeCenterX[1] = i + 2;
                    pokeCenterX[2] = i + 1;
                    pokeCenterX[3] = i + 2;
                    // STORE Y COORDINATES FOR CHEATS
                    pokeCenterY[0] = j;
                    pokeCenterY[1] = j;
                    pokeCenterY[2] = j + 1;
                    pokeCenterY[3] = j + 1;
                    return;
                }
            }
        }
    }
}

// Function to place the PokeCenter along the corresponding path.
void placePokeCenter(char map[HEIGHT][WIDTH])
{
    int i, j;

    for (i = HEIGHT - 1; i > 0; i--)
    {
        for (j = WIDTH -1; j > 0; j--)
        {
            if (map[i][j] == '#')
            {
                if (map[i - 1][j] != '#' && map[i - 1][j] != ':' && map[i - 1][j] != '%' && map[i - 1][j] != 'M' && map[i - 1][j] != 'C' && map[i - 1][j - 1] != '#' && map[i - 1][j - 1] != ':' && map[i - 1][j - 1] != '%' && map[i - 1][j - 1] != 'M' && map[i - 1][j - 1] != 'C' && map[i - 2][j] != '#' && map[i - 2][j] != ':' && map[i - 2][j] != '%' && map[i - 2][j] != 'M' && map[i - 2][j] != 'C' && map[i - 2][j - 1] != '#' && map[i - 2][j - 1] != ':' && map[i - 2][j - 1] != '%' && map[i - 2][j - 1] != 'M' && map[i - 2][j - 1] != 'C')
                {
                    map[i - 1][j] = 'C';
                    map[i - 2][j] = 'C';
                    map[i - 1][j - 1] = 'C';
                    map[i - 2][j - 1] = 'C';

                    // STORE X COORDINATES FOR CHEATS
                    pokeCenterX[0] = i - 1;
                    pokeCenterX[1] = i - 2;
                    pokeCenterX[2] = i - 1;
                    pokeCenterX[3] = i - 2;

                    // STORE Y COORDINATES FOR CHEATS
                    pokeCenterY[0] = j;
                    pokeCenterY[1] = j;
                    pokeCenterY[2] = j - 1;
                    pokeCenterY[3] = j - 1;
                    return;
                }
            }
        }
    }
}

// Function to randomly generate the map using a seed.
void seededGeneration(char map[HEIGHT][WIDTH])
{
    seed = generateSeed();
    srand(seed);
    rand();

    initializeMap(mapArray);
    tallGrassRegions(mapArray);
    placeExits(mapArray);
    buildPaths(mapArray);
    placePokeMart(mapArray);
    placePokeCenter(mapArray);
    printMap(mapArray);
}

// Function to randomly generate the map.
void randomGeneration(char map[HEIGHT][WIDTH])
{
    srand(time(NULL));
    rand();

    initializeMap(mapArray);
    tallGrassRegions(mapArray);
    placeExits(mapArray);
    buildPaths(mapArray);
    placePokeMart(mapArray);
    placePokeCenter(mapArray);
    printMap(mapArray);
}